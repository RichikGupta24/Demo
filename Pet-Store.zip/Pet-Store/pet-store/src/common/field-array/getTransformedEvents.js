const getTransformedEvents = (eventProps, fieldValues, setFieldValues, type) => {
  const { onChange, ...rest } = eventProps
  const transformedOnChange = index => event => {
    const enteredValue = event.target.value
    fieldValues[index] = enteredValue
    setFieldValues([...fieldValues])
    onChange(event, index, enteredValue, fieldValues)
  }
  const transformedOnChangeComposite = index => value => {
    fieldValues[index] = value
    setFieldValues([...fieldValues])
    onChange(index, value, fieldValues)
  }
  return {onChange: type === 'simple'?  transformedOnChange : transformedOnChangeComposite, ...rest}
}

const getTransformedEventProps = (index, eventProps, fieldValues, setFieldValues, type) => {
  const transformedEvents = getTransformedEvents(eventProps,fieldValues, setFieldValues, type)
  const indexedEventProps =
  Object.keys(transformedEvents)
  .reduce((events, key) => ({...events, [key]: transformedEvents[key](index)}), {})
  return indexedEventProps
}

export default getTransformedEventProps
