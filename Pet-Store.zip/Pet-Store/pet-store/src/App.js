import './App.css'

import AddPet from './add-pet/AddPet'

function App() {
  return (
    <div className="App">
      <AddPet/>
    </div>
  );
}

export default App;
