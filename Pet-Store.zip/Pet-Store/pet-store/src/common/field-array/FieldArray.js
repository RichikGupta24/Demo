import React, { useCallback, useState } from 'react'
import PropTypes from 'prop-types'
import Grid from '@material-ui/core/Grid'

import useFieldArray from './useFieldArray'
import getTransformedEventProps from './getTransformedEvents'

const FieldArray = ({className, fieldId, fieldName, Field, fieldProps, eventProps, type = "simple"}) => {
  const { fields, addField, removeField, fieldValues, setFieldValues } = useFieldArray(fieldName, type)
  return (
    <>
    {fields.map((field, index) => {
      const indexedEventProps = getTransformedEventProps(index, eventProps,fieldValues, setFieldValues, type)
          return (
            <Grid container key={`${fieldName}-${index}`} className={className}>
              <Field index={index} id={`${fieldId}-${index}`} value={fieldValues[index]} {...fieldProps} {...indexedEventProps} name={`${fieldName}-${index}`}/>
              {index === fields.length -1 && <button type="button" onClick={() => addField(index)}>+</button>}
              { index > 0 && <button type="button" onClick={() => removeField(index)}>-</button>}
            </Grid>
          )
        })}
    </>
  )
}

FieldArray.propTypes = {
  fieldName: PropTypes.string.isRequired
}

export default FieldArray
