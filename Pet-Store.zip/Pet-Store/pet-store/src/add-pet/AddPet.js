import React, {useCallback, useState} from 'react'
import { makeStyles } from '@material-ui/core/styles'
import TextField from '@material-ui/core/TextField'
import InputLabel from '@material-ui/core/InputLabel'
import MenuItem from '@material-ui/core/MenuItem'
import Select from '@material-ui/core/Select'
import { FormControl } from '@material-ui/core'

import Tag from './tag/Tag'
import FieldArray from '../common/field-array/FieldArray'

const useStyles = makeStyles((theme) => ({
  root: {
    padding: '20px'
  },
  formField: {
    'padding-bottom': '20px',

  },
  select: {
    margin: theme.spacing(1),
    minWidth: 120,
    'padding-bottom': '20px',
  }
}));

export const AddPet = ({}) => {
  const classes = useStyles();
  const [numberOfTags, setNumberOfTags] = useState(1)
  const [numberOfUrls, setNumberOfURLs] = useState(1)
  const addTag = useCallback(() => setNumberOfTags(numberOfTags + 1))
  const removeTag = useCallback(() => setNumberOfTags(numberOfTags - 1))
  const addUrl = useCallback(() => setNumberOfURLs(numberOfUrls + 1))
  const removeUrl = useCallback(() => setNumberOfURLs(numberOfUrls - 1))
  const tagElements = Array.from({ length: numberOfTags})
  const urlElements = Array.from({ length: numberOfUrls})

  const [id, setId] = useState('')
  const [name, setName] = useState('')
  const [category, setCategory] = useState('')
  const [status, setStatus] = useState('')
  const [tags, setTags] = useState([{id: '', name: ''}])
  const [urls, setUrls] = useState([])

  const onSubmit = useCallback((event) => {
    event.preventDefault()
    console.log('id', id)
    console.log('name', name)
    console.log('category', category)
    console.log('status', status)
    console.log('urls', urls)
    console.log('tags', tags)
  })
  const handleUrlsEntry = (event, index, value, urls) => {
    setUrls(urls)
  }
const handleTagsEntry = (index, value, tags) => {
  console.log('tags Composite', tags)
  setTags(tags)
}

  return (
    <form className={classes.root} noValidate autoComplete="off" onSubmit={onSubmit}>
      <h1>Add a Pet</h1>
      <div className={classes.formField}>
      <TextField
        id="pet-id"
        label="PetId"
        type="number"
        size="small"
        placeholder="0"
        variant="outlined"
        onInput={ e=>setId(e.target.value)}
      />
      </div>
      <FormControl className={classes.select}>
        <InputLabel id="category-label">Category</InputLabel>
          <Select
            labelId="category-label"
            id="pet-category"
            value="10"
            size="small"
            variant="outlined"
            onChange={ e=>setCategory(e.target.value)}
          >
            <MenuItem value={10}>Category 1</MenuItem>
            <MenuItem value={20}>Category 2</MenuItem>
            <MenuItem value={30}>Category 3</MenuItem>
          </Select>
        </FormControl>
        <div className={classes.formField}>
          <TextField id="pet-name" label="Name" size="small" variant="outlined" onInput={ e=>setName(e.target.value)}/>
        </div>

        <FieldArray
          className={classes.formField}
          fieldName="url"
          Field={TextField}
          fieldId="pet-photo-url"
          fieldProps={{label:"PhotoURL", size: 'small', variant: 'outlined' }}
          eventProps={{onChange: handleUrlsEntry}}
        />
        <FieldArray
          className={classes.formField}
          fieldName="tag"
          Field={Tag}
          fieldProps={{tagIdId: 'pet-tag-name', tagIdLabel:"Tag Id", tagNameId:'pet-tag-id', tagNameLabel:"Tag Name", size: 'small', variant: 'outlined' }}
          eventProps={{onChange: handleTagsEntry}}
          type="composite"
        />
        <div className={classes.select}>
      <InputLabel id="demo-simple-select-label">Status</InputLabel>
        <Select
          labelId="demo-simple-select-label"
          id="pet-status"
          variant="outlined"
          size="small"
          onChange={ e=>setStatus(e.target.value)}
        >
          <MenuItem value={10}>Available</MenuItem>
          <MenuItem value={20}>Category 2</MenuItem>
          <MenuItem value={30}>Category 3</MenuItem>
        </Select>
        </div>
        <button>Submit</button>
    </form>
  )
}

export default AddPet