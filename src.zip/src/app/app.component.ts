import { Component, OnInit } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { StoreService } from './services/store.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  currentRoute: string = '';
  isGenerateSnippetClicked: boolean = false;
  constructor(private router: Router, private ss: StoreService) {

  }

  ngOnInit() {
    this.router.events.subscribe((event: any) => {
      switch (true) {
        case event instanceof NavigationEnd: {
          this.currentRoute = this.router.url;
          break;
        }
      }
    });
    this.getGeneratedCodeFlagInfo();
  }

  getGeneratedCodeFlagInfo() {
    this.ss.getGeneratedFlagInfo().subscribe((res: boolean) => {
      this.isGenerateSnippetClicked = res;
    });
  }

}
