import React, { useCallback, useState } from 'react'
import Grid from '@material-ui/core/Grid'
import TextField from '@material-ui/core/TextField'

const Tag = ({
    index,
    tagNameId,
    tagIdId,
    tagNameLabel,
    tagIdLabel,
    size,
    variant,
    onChange }) => {

  const [id, setId] = useState('')
  const [name, setName] = useState('')
  const onIdChange = useCallback((event) => {
    setId(event.target.value)
    onChange({name, id:event.target.value})
  })
  const onNameChange = useCallback((event) => {
    setName(event.target.value)
    onChange({name:event.target.value, id})
  })
  return (
    <>
      <Grid item xs={4} style={{'margin-right': '16px'}}>
        <TextField id={`${tagIdId}-${index}`} label={tagIdLabel} size={size} variant={variant} onChange={onIdChange} value={id}/>
      </Grid>
      <Grid item xs={4}>
        <TextField id={`${tagNameId}-${index}`} label={tagNameLabel} size={size} variant={variant} onChange={onNameChange} value={name}/>
      </Grid>
    </>
  )
}

export default Tag