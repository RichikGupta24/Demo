import { useCallback, useState } from 'react'

const useFieldArray = (name) => {
  const [numberOfFields, setNumberOfField] = useState(1)
  const [fieldValues, setFieldValues] = useState([''])
  const fields = Array.from({ length: numberOfFields})
  const addField = useCallback((index) => {
    setFieldValues(fieldValues.concat(['']))
    setNumberOfField(numberOfFields + 1)
  }, [numberOfFields,setNumberOfField, fieldValues, setFieldValues])
  const removeField = useCallback((index) => {
    setFieldValues(fieldValues.slice(0, index).concat(fieldValues.slice(index+1)))
    setNumberOfField(numberOfFields - 1)
  }, [numberOfFields,setNumberOfField])
  return {fields, addField, removeField, fieldValues, setFieldValues}
}

export default useFieldArray
